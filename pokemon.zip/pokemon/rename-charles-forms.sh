#!/bin/bash

echo "Unown"
mv 201-11.png 201-1.png
mv 201-12.png 201-2.png
mv 201-13.png 201-3.png
mv 201-14.png 201-4.png
mv 201-15.png 201-5.png
mv 201-16.png 201-6.png
mv 201-17.png 201-7.png
mv 201-18.png 201-8.png
mv 201-19.png 201-9.png
mv 201-20.png 201-10.png
mv 201-21.png 201-11.png
mv 201-22.png 201-12.png
mv 201-23.png 201-13.png
mv 201-24.png 201-14.png
mv 201-25.png 201-15.png
mv 201-26.png 201-16.png
mv 201-27.png 201-17.png
mv 201-28.png 201-18.png
mv 201-29.png 201-19.png
mv 201-30.png 201-20.png
mv 201-31.png 201-21.png
mv 201-32.png 201-22.png
mv 201-33.png 201-23.png
mv 201-34.png 201-24.png
mv 201-35.png 201-25.png
mv 201-36.png 201-26.png
mv 201-37.png 201-27.png
mv 201-38.png 201-28.png

echo "Castform"
mv 351-11.png 351-29.png
mv 351-12.png 351-30.png
mv 351-13.png 351-31.png
mv 351-14.png 351-32.png

echo "Deoxys"
mv 386-11.png 386-33.png
mv 386-12.png 386-34.png
mv 386-13.png 386-35.png
mv 386-14.png 386-36.png

echo "Spinda"
mv 327-11.png 327-37.png
mv 327-12.png 327-38.png
mv 327-13.png 327-39.png
mv 327-14.png 327-40.png
mv 327-15.png 327-41.png
mv 327-16.png 327-42.png
mv 327-17.png 327-43.png
mv 327-18.png 327-44.png

echo "Rattata"
mv 19-61.png 19-46.png
cp 19.png 19-45.png

echo "Raticate"
mv 20-61.png 20-48.png
cp 20.png 20-47.png

echo "Raichu"
mv 26-61.png 26-50.png
cp 26.png 26-49.png

echo "Sandshrew"
mv 27-61.png 27-52.png
cp 27.png 27-51.png

echo "Sandslash"
mv 28-61.png 28-54.png
cp 28.png 28-53.png

echo "Vulpix"
mv 37-61.png 37-56.png
cp 37.png 37-55.png

echo "Ninetales"
mv 38-61.png 38-58.png
cp 38.png 38-57.png

echo "Diglett"
mv 50-61.png 50-60.png
cp 50.png 50-59.png

echo "Dugtrio"
mv 51-61.png 51-62.png
cp 51.png 51-61.png

echo "Meowth"
mv 52-61.png 52-64.png
cp 52.png 52-63.png

echo "Persian"
mv 53-61.png 53-66.png
cp 53.png 53-65.png

echo "Geodude"
mv 74-61.png 74-68.png
cp 74.png 74-67.png

echo "Graveler"
mv 75-61.png 75-70.png
cp 75.png 75-69.png

echo "Golem"
mv 76-61.png 76-72.png
cp 76.png 76-71.png

echo "Grimer"
mv 88-61.png 88-74.png
cp 88.png 88-73.png

echo "Muk"
mv 89-61.png 89-76.png
cp 89.png 89-75.png

echo "Exeggutor"
mv 103-61.png 103-78.png
cp 103.png 103-77.png

echo "Marowak"
mv 105-61.png 105-80.png
cp 105.png 105-79.png

echo "Giratina"
mv 487-11.png 487-90.png
mv 487-12.png 487-91.png
